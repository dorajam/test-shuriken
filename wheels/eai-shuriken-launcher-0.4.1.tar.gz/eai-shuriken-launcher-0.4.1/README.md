# eai-shuriken-launcher

## Usage

### Requirements

To run **eai-shuriken-launcher**, you will need:

* Python ≥ 3.7
* [The toolkit cli](
  https://docs.console.elementai.com/pages/tutorial.html#install-the-cli)


### Installing

To install **eai-shuriken-launcher**, make sure you have access to the
[ElementAI internal PyPI eai-core
repo](https://pypi.elmt.io/dashboard/repositories/eai-core/), and that
`pip` is [configured to install packages from
there](https://github.com/ElementAI/pypi#using-pipconf). Then, run:

```
pip install eai-shuriken-launcher
```
