import re
import subprocess
import tempfile
from pathlib import Path
from typing import Any, List, Optional, cast

import structlog
import yaml

from eai.shuriken.common.exceptions import ShurikenRuntimeError
from eai.shuriken.common.typing import JsonSerializableDict

logger = structlog.get_logger(__name__)

TOOLKIT_REGISTRY = "registry.console.elementai.com"
UUID_PATTERN = re.compile(
    r"[0-9a-f]{8}\-[0-9a-f]{4}\-[0-9a-f]{4}\-[0-9a-f]{4}\-[0-9a-f]{12}"
)


def base_toolkit_command(
    command: List[str], **kwargs: Any
) -> subprocess.CompletedProcess:
    """
    Run a Toolkit (``eai``) command in a subprocess.

    :param command: The command to run, ex. ``["eai", "login"]``.
    """
    try:

        return subprocess.run(command, **kwargs)
    except FileNotFoundError:
        raise ShurikenRuntimeError(
            'Could not find "eai". Please make sure Toolkit is installed.'
        )
    except subprocess.CalledProcessError as e:
        raise ShurikenRuntimeError(str(e))


def toolkit_command(command: List[str]) -> str:
    """
    Run a Toolkit (``eai``) command and return the output.

    :param command: The command to run, ex. ``["eai", "login"]``.
    """

    return cast(
        str, base_toolkit_command(command, stdout=subprocess.PIPE).stdout.decode()
    )


def _extract_uuid(output: str) -> str:
    """
    Extract and validate a uuid from an output of ``toolkit_command``.
    """
    lines = output.splitlines()
    if len(lines) != 1:
        raise ShurikenRuntimeError(f"{lines} Not a valid uuid.")
    line = lines[0].strip()
    if UUID_PATTERN.fullmatch(line) is None:
        raise ShurikenRuntimeError(f'"{line}" is not a valid uuid.')
    return line


def _resolve_uuid(full_name: str, type: str) -> str:
    output = toolkit_command(
        ["eai", type, "get", "--fields", "id", "--no-header", full_name]
    )
    return _extract_uuid(output)


def resolve_account(full_name: Optional[str] = None) -> str:
    """
    Resolve an account reference into a uuid.

    :param full_name: The full name or uuid of an account.
    """
    if full_name is None:
        # Hack to not provide a name argument
        full_name = "--"
    return _resolve_uuid(full_name, "account")


def resolve_team(full_name: str) -> str:
    """
    Resolve a team reference into a uuid.

    :param full_name: The full name or uuid of a team.
    """
    return _resolve_uuid(full_name, "team")


def resolve_data(full_name: str) -> str:
    """
    Resolve a data object reference into a uuid.

    :param full_name: The full name or uuid of a data object.
    """
    return _resolve_uuid(full_name, "data")


def resolve_role(full_name: str) -> str:
    """
    Resolve a role reference into a uuid.

    :param full_name: The full name or uuid of a role.
    """
    return _resolve_uuid(full_name, "role")


def resolve_volume(volume: str) -> str:
    """
    Resolve the data object part of a volume (--data) into a uuid.
    The expected format is "{name}[@{version}]:{mount}[:{options}].

    :param volume: A Toolkit volume specification.
    """
    volume_split = volume.split(":", 1)
    if len(volume_split) < 2:
        raise ValueError(f'Invalid volume: "{volume}": missing ":" separator.')
    data, mount = volume_split
    if "@" in data:
        full_name, version = data.split("@", 1)
    else:
        full_name = data
        version = "latest"

    uuid = resolve_data(full_name)
    return f"{uuid}@{version}:{mount}"


def resolve_image(image: str) -> str:
    """
    Resolve the account part of an image into a uuid.
    The expected format is "{registry}/{account}/{name}[:{version}].

    :param volume: An image tag belonging to the Toolkit registry.
    """
    image_split = image.split("/", 2)
    if len(image_split) < 2:
        raise ValueError(
            f'Invalid image: "{image}": not of the form "{TOOLKIT_REGISTRY}/account/name:version".'
        )
    registry, account, name = image_split
    if registry != TOOLKIT_REGISTRY:
        raise ValueError(
            f'Invalid image: "{image}": does not belong to the registry "{TOOLKIT_REGISTRY}".'
        )
    uuid = resolve_account(account)
    return f"{registry}/{uuid}/{name}"


def get_job_info(full_name: str) -> JsonSerializableDict:
    output = toolkit_command(["eai", "job", "get", full_name])
    return yaml.safe_load(output)


def validate_login() -> None:
    """
    Make sure the user is properly logged in with Toolkit.
    """
    toolkit_command(["eai", "login", "validate"])


def follow_job(job_uuid: str) -> None:
    logger.info(f"Following the job {job_uuid}. Press ctrl-c to stop following. ")
    try:
        base_toolkit_command(["eai", "job", "logs", "-f", job_uuid])
    except KeyboardInterrupt:
        # Add an empty print to ensure the next logs start on a new line.
        print()
        logger.info(
            f"No longer following the launched job. "
            f'Use "eai job logs -f {job_uuid}" to resume.'
        )
    else:
        logger.info("The followed job has ended. Returning to the main program.")


def _make_full_name(name: Optional[str] = None, account: Optional[str] = None) -> str:
    """
    Generate the full name of a toolkit object from a name and parent account.

    :param name: The name of the object. If not provided, the object remains unnamed.
    :param account: The parent account for the object.
        If not provided, the user's sandbox account is used.
    """
    if name is None:
        name = ""
    elif "." in name:
        raise ShurikenRuntimeError(f'Invalid name "{name}"')
    if account is None:
        account = resolve_account()
    return ".".join([account, name])


def create_data(name: Optional[str] = None, account: Optional[str] = None) -> str:
    """
    Create an empty data object.

    :param name: The name of the data object. If not provided, the object remains unnamed.
    :param account: The parent account for the data object.
        If not provided, the user's sandbox account is used.
    """
    full_name = _make_full_name(name, account)
    command = ["eai", "data", "new", "--fields", "id", "--no-header", full_name]
    output = toolkit_command(command)
    uuid = _extract_uuid(output)
    logger.info(f'Created data "{full_name}"', id=uuid)
    return uuid


def push_data(data_id: str, path: Path) -> None:
    """
    Upload the content of a directory to a data object.

    :param data_id: The (resolved) uuid of the data object.
    :param path: The path to the directory to push.
    """
    toolkit_command(["eai", "data", "push", data_id, str(path)])


def pull_data(data_id: str, path: Path) -> str:
    """
    Download the content of a data object to a directory.

    :param data_id: The (resolved) uuid of the data object.
    :param path: The path where to download the data.
    """
    return toolkit_command(["eai", "data", "pull", data_id, str(path)])


def create_role(*, name: Optional[str] = None, account: str) -> str:
    """
    Create an new role with no policy.

    :param name: The name of the role. If not provided, the object remains unnamed.
    :param account: The parent account for the data object.
        If not provided, the user's sandbox account is used.
    """
    full_name = _make_full_name(name, account)
    command = ["eai", "role", "new", "--fields", "id", "--no-header", full_name]
    output = toolkit_command(command)
    uuid = _extract_uuid(output)
    logger.info(f'Created role "{full_name}"', id=uuid)
    return uuid


def create_policy(role: str, policy: str) -> str:
    command = [
        "eai",
        "role",
        "policy",
        "new",
        "--fields",
        "id",
        "--no-header",
        role,
        policy,
    ]
    print(command)
    output = toolkit_command(command)
    uuid = _extract_uuid(output)
    logger.info(f'Created policy "{policy}"', role=role, id=uuid)
    return uuid


def submit_job(
    job_definition: JsonSerializableDict,
    *,
    account: Optional[str] = None,
    role: Optional[str] = None,
) -> str:
    """

    :param job_definition: A dictionary definition for the job. See the
        `Toolkit documentation <https://docs.console.elementai.com/pages/jobs.html>`__ for details.
    :param account: The account where the job will be launched.
    :param role: A role for the job. Needed for using Toolkit inside the job.
    """
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "job.yaml"
        with path.open("w") as file_buffer:
            yaml.safe_dump(job_definition, stream=file_buffer)

        command = [
            "eai",
            "job",
            "submit",
            "-f",
            str(path),
            "--no-header",
            "--fields=id",
        ]
        if account is not None:
            command += ["--account", account]
        if role is not None:
            command += ["--role", role]
        return _extract_uuid(toolkit_command(command))
