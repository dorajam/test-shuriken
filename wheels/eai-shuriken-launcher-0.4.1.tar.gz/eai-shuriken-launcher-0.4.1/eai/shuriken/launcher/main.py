import argparse
import json
import textwrap
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog
import yaml

from eai.shuriken.common.cli import CliContext
from eai.shuriken.common.exceptions import ShurikenValueError
from eai.shuriken.common.logging import configure_logging
from eai.shuriken.launcher.launch_experiment import launch_experiment

log = structlog.get_logger(__name__)


def arg_parser() -> argparse.ArgumentParser:
    """
    Creates an argument parser for the script.

    :param prog: The base command for this program.
    """
    parser = argparse.ArgumentParser(
        description=textwrap.dedent(str(main.__doc__)),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument(
        "experiment_config",
        help="A path to an experiment configuration file.",
        type=Path,
    )
    parser.add_argument("-d", "--experiment-data-id", required=True)
    parser.add_argument("-a", "--account", help="The account for the job.")
    parser.add_argument(
        "--run",
        action="store_false",
        dest="dry_run",
        default=True,
        help="Launch the experiment.",
    )
    parser.add_argument(
        "-f",
        "--follow",
        action="store_true",
        default=False,
        help="Follow the launched job.",
    )
    parser.add_argument(
        "-i",
        "--worker-image",
        help="The Docker image to use for the worker. Must be pushed to the Toolkit registry first.",
    )
    parser.add_argument(
        "--agent-image",
        help="The Docker image to use for the agent. Must be pushed to the Toolkit registry first.",
    )
    return parser


def parse_args(
    *, args: Optional[List[str]] = None, parser: argparse.ArgumentParser
) -> Dict[str, Any]:
    """
    Construct and run the parser. Also parse the configuration parameters.

    :param args: If provided, parse this instead of sys.argv.
    """
    arg_dict = parser.parse_args(args).__dict__

    # Get the experiment config.
    experiment_config_path = arg_dict["experiment_config"]
    with experiment_config_path.open("r") as file_buffer:
        ext = experiment_config_path.suffix
        if ext == ".json":
            arg_dict["experiment_config"] = json.load(file_buffer)
        elif ext in (".yaml", ".yml"):
            arg_dict["experiment_config"] = yaml.safe_load(file_buffer)
        else:
            raise ShurikenValueError(
                f'Invalid file format "{ext}" for the experiment configuration. '
                f'Supported formats are ".json" and ".yaml".'
            )

    return arg_dict


def main(args: Optional[List[str]] = None) -> None:
    """
    The entrypoint for the Shuriken agent.

    :param args: If provided, parse this instead of sys.argv.
    """

    with CliContext():
        parser = arg_parser()
        arg_dict = parse_args(args=args, parser=parser)
        launch_experiment(**arg_dict)


def cli_main(args: Optional[List[str]] = None) -> None:
    configure_logging()
    main(args)


if __name__ == "__main__":
    cli_main()
