from copy import deepcopy

import structlog

from eai.shuriken.common.exceptions import ShurikenValueError
from eai.shuriken.common.utils import parse_function_string

log = structlog.get_logger(__name__)


def address_breaking_changes(experiment_config):
    experiment_config = deepcopy(experiment_config)

    # Renamed ``parameters`` to ``algorithm`` in the experiment configuration.
    if "parameters" in experiment_config:
        log.warn(
            'The "parameters" configuration entry is deprecated. '
            'Please use "algorithm" instead.'
        )
        experiment_config["algorithm"] = experiment_config.pop("parameters")

    # Removed the ``metrics`` entry in the experiment configuration (#28).
    if "metrics" in experiment_config:
        log.warn(
            'The "metrics" experiment configuration entry is no longer supported. '
            "It will be ignored."
        )
        del experiment_config["metrics"]

    # The ``metric`` configuration entry has been moved from the algorithm to the experiment (#28).
    if "metric" in experiment_config["algorithm"]["config"]:
        log.warn(
            'The "metric" algorithm configuration entry now belongs to the'
            "experiment configuration."
        )
        experiment_config["metric"] = experiment_config["algorithm"]["config"]["metric"]
        del experiment_config["algorithm"]["config"]["metric"]

    # Removed the ``use_cmd_flags`` entry in the experiment configuration (#26).
    if "use_cmd_flags" in experiment_config:
        raise ShurikenValueError(
            'The "use_cmd_flags" experiment configuration entry is no longer supported.'
        )

    algorithm = experiment_config["algorithm"]
    while True:
        # Removed the ``n_workers`` entry in the algorithm configurations (#30).
        if "n_workers" in algorithm["config"]:
            log.warn(
                '"n_workers" is no longer an entry in the algorithm configuration.'
            )
            del algorithm["config"]["n_workers"]

        # Removed the ``random_seed`` entry in the grid search configuration (#30).
        if algorithm["name"] == "GridSearch" and "random_seed" in algorithm["config"]:
            log.warn(
                '"random_seed" is no longer an entry in the GridSearch configuration.'
            )
            del algorithm["config"]["random_seed"]

        # Removed the ``random_seed`` entry in the hyperband configuration (#40).
        if algorithm["name"] == "Hyperband" and "random_seed" in algorithm["config"]:
            log.warn(
                '"random_seed" is no longer an entry in the Hyperband configuration. '
                "Set the random seed directly in the strategy configuration instead."
            )
            algorithm["config"]["strategy"]["config"]["random_seed"] = algorithm[
                "config"
            ]["random_seed"]
            del algorithm["config"]["random_seed"]

        # The distributions ``normal``, ``lognormal``, ``lograndint`` are no longer available (#31).
        if algorithm["name"] == "RandomSearch":
            for name, dimension in algorithm["config"]["dimensions"].items():
                try:
                    prior, args, kwargs = parse_function_string(dimension)
                except ShurikenValueError:
                    pass
                else:
                    if prior in ("normal", "lognormal", "lograndint"):
                        msg = f"The prior {prior} is no longer supported."
                        if prior in ("normal", "lognormal"):
                            suggest_prior = prior[:-2]
                            msg += (
                                f" Use {suggest_prior} instead."
                                f" See https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.{suggest_prior}.html"
                            )
                            raise ShurikenValueError(msg)

        if "strategy" in algorithm["config"]:
            algorithm = algorithm["config"]["strategy"]
        else:
            break
    return experiment_config
