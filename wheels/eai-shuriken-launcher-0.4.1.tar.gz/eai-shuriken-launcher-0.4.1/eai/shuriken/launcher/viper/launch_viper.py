from typing import Optional

import structlog
import yaml

from eai.shuriken.common.utils import get_list_from_environment
from eai.shuriken.launcher.toolkit import (
    create_policy,
    create_role,
    follow_job,
    resolve_account,
    resolve_role,
    resolve_volume,
    submit_job,
    toolkit_command,
    validate_login,
)

log = structlog.get_logger(__name__)


def launch_viper(
    experiment_data_id: str,
    experiment_data_mount: str = "/eai_shuriken_data",
    dry_run: bool = False,
    image: Optional[str] = None,
    account: Optional[str] = None,
    follow: bool = False,
    role: Optional[str] = None,
) -> Optional[str]:

    data = f"{experiment_data_id}:{experiment_data_mount}"

    # Resolve the data and image.
    if not dry_run:
        validate_login()
        data = resolve_volume(data)
        account = resolve_account(account)

        if role is None:
            role = create_role(account=account)
            organization = toolkit_command(
                [
                    "eai",
                    "account",
                    "get",
                    account,
                    "--fields",
                    "organization",
                    "--no-header",
                    "--no-human-readable",
                ]
            ).strip()
            create_policy(role, f"user:get@{organization}:user:*")

        else:
            role = resolve_role(role)

    # The job configuration for the agent.
    if image is None:
        image = "registry.console.elementai.com/shared.image/eai-experiment-viper"

    job_config = {
        "image": image,
        "preemptable": False,
        "resources": {"mem": 1, "cpu": 1},
        "options": {"alphabits": {"fusionflex": "v2"}},
        "data": [data],
        "environmentVars": get_list_from_environment(
            {"MLFLOW_TRACKING_URI": experiment_data_mount, "DEV": True}
        ),
    }

    # Show the agent configuration.
    log.info(f"Job configuration: \n{yaml.safe_dump(job_config)}")

    if not dry_run:
        job_uuid: str = submit_job(job_config, account=account, role=role)
        log.info(f"Job uuid: {job_uuid}")
        job_data = yaml.safe_load(toolkit_command(["eai", "job", "get", job_uuid]))
        log.info(f"Viper URL: {job_data['accessUrl']}")
        if follow:
            follow_job(job_uuid)
        return job_uuid
    return None
