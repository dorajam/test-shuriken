import argparse
import textwrap
from typing import Any, Dict, List, Optional

import structlog

from eai.shuriken.common.cli import CliContext
from eai.shuriken.common.logging import configure_logging
from eai.shuriken.launcher.viper.launch_viper import launch_viper

log = structlog.get_logger(__name__)


def arg_parser() -> argparse.ArgumentParser:
    """
    Creates an argument parser for the script.

    :param prog: The base command for this program.
    """
    parser = argparse.ArgumentParser(
        description=textwrap.dedent(str(main.__doc__)),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument("-d", "--experiment-data-id", required=True)
    parser.add_argument("-a", "--account", help="The account for the job.")
    parser.add_argument(
        "-r",
        "--role",
        help="A role to use for the job. If not provided a role is created on the fly.",
    )
    parser.add_argument(
        "--run",
        action="store_false",
        dest="dry_run",
        default=True,
        help="Launch the experiment.",
    )
    parser.add_argument(
        "-f",
        "--follow",
        action="store_true",
        default=False,
        help="Follow the launched job.",
    )
    parser.add_argument(
        "-i",
        "--image",
        help="The Docker image to use for Viper, if different from the default.",
    )
    return parser


def parse_args(
    *, args: Optional[List[str]] = None, parser: argparse.ArgumentParser
) -> Dict[str, Any]:
    """
    Construct and run the parser. Also parse the configuration parameters.

    :param args: If provided, parse this instead of sys.argv.
    """
    arg_dict = parser.parse_args(args).__dict__
    return arg_dict


def main(args: Optional[List[str]] = None) -> None:
    """
    The entrypoint for the Shuriken agent.

    :param args: If provided, parse this instead of sys.argv.
    """

    with CliContext():
        parser = arg_parser()
        arg_dict = parse_args(args=args, parser=parser)
        launch_viper(**arg_dict)


def cli_main(args: Optional[List[str]] = None) -> None:
    configure_logging()
    main(args)


if __name__ == "__main__":
    cli_main()
