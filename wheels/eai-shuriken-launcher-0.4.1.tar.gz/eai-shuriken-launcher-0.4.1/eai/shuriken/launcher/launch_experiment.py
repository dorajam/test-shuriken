import json
from typing import Optional

import structlog
import yaml

from eai.shuriken.common.typing import JsonSerializableDict
from eai.shuriken.common.utils import get_list_from_environment
from eai.shuriken.launcher import __version__
from eai.shuriken.launcher.compatibility import address_breaking_changes
from eai.shuriken.launcher.toolkit import (
    follow_job,
    resolve_image,
    resolve_volume,
    submit_job,
    validate_login,
)

log = structlog.get_logger(__name__)


def launch_experiment(
    experiment_config: JsonSerializableDict,
    experiment_data_id: str,
    experiment_data_mount: str = "/eai_shuriken_data",
    dry_run: bool = False,
    worker_image: Optional[str] = None,
    agent_image: Optional[str] = None,
    account: Optional[str] = None,
    follow: bool = False,
) -> Optional[str]:
    experiment_config = address_breaking_changes(experiment_config)

    worker_config = experiment_config["worker_config"]

    # Add the experiment data
    if "data" not in worker_config:
        worker_config["data"] = []
    worker_config["data"].append(f"{experiment_data_id}:{experiment_data_mount}")

    if worker_image is not None:
        worker_config["image"] = worker_image

    # Resolve the data and image.
    if not dry_run:
        validate_login()
        worker_config["data"] = [resolve_volume(data) for data in worker_config["data"]]
        if "image" in worker_config:
            worker_config["image"] = resolve_image(worker_config["image"])

    # Show the configuration.
    log.info(f"Experiment configuration: \n{yaml.safe_dump(experiment_config)}")

    # The job configuration for the agent.
    if agent_image is None:
        agent_image = f"registry.console.elementai.com/shared.image/eai-shuriken-runner:v{__version__}"

    # Rename the worker mounts in the agent to avoid accidental name conflicts.
    agent_data = [
        f"{volume.split(':')[0]}:/eai_shuriken_worker_mount_{i}"
        for i, volume in enumerate(worker_config["data"][:-1])
    ] + worker_config["data"][-1:]

    agent_config = {
        "image": agent_image,
        "preemptable": True,
        "resources": {"mem": 4, "cpu": 2},
        "options": {"alphabits": {"fusionflex": "v2"}},
        "data": agent_data,
        "environmentVars": get_list_from_environment(
            {"EAI_EXPERIMENT_CONFIG": json.dumps(experiment_config)}
        ),
        "command": ["shuriken-agent", "--directory", experiment_data_mount],
        "isProcessAgent": True,
    }

    # Show the agent configuration.
    log.info(f"Agent configuration: \n{yaml.safe_dump(agent_config)}")

    if not dry_run:
        job_uuid: str = submit_job(agent_config, account=account)
        log.info(f"Agent uuid: {job_uuid}")
        if follow:
            follow_job(job_uuid)
        return job_uuid
    return None
