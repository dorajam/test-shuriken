# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['eai', 'eai.shuriken.launcher', 'eai.shuriken.launcher.viper']

package_data = \
{'': ['*']}

install_requires = \
['colorama>=0.4.1,<0.5.0',
 'eai-shuriken-common>=0.4.1,<0.5.0',
 'pyyaml>=5.3.1,<6.0.0',
 'structlog>=19.2.0,<20.0.0']

entry_points = \
{'console_scripts': ['shuriken-launch = eai.shuriken.launcher.main:cli_main',
                     'shuriken-launch-viper = '
                     'eai.shuriken.launcher.viper.main:cli_main']}

setup_kwargs = {
    'name': 'eai-shuriken-launcher',
    'version': '0.4.1',
    'description': 'Shuriken',
    'long_description': '# eai-shuriken-launcher\n\n## Usage\n\n### Requirements\n\nTo run **eai-shuriken-launcher**, you will need:\n\n* Python ≥ 3.7\n* [The toolkit cli](\n  https://docs.console.elementai.com/pages/tutorial.html#install-the-cli)\n\n\n### Installing\n\nTo install **eai-shuriken-launcher**, make sure you have access to the\n[ElementAI internal PyPI eai-core\nrepo](https://pypi.elmt.io/dashboard/repositories/eai-core/), and that\n`pip` is [configured to install packages from\nthere](https://github.com/ElementAI/pypi#using-pipconf). Then, run:\n\n```\npip install eai-shuriken-launcher\n```\n',
    'author': 'Element AI',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
