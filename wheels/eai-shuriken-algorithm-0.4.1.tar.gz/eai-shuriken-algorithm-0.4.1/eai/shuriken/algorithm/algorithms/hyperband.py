from copy import deepcopy
from typing import List

import numpy as np
import structlog

from eai.shuriken.algorithm.algorithm import Algorithm
from eai.shuriken.algorithm.algorithms.bayes_search import BayesSearch
from eai.shuriken.common.trial import Trial
from eai.shuriken.common.typing import JsonSerializableDict

logger = structlog.get_logger(__name__)


class Hyperband(Algorithm):
    def __init__(
        self,
        strategy: BayesSearch,
        budget_key: str = "n_iterations",
        max_iter: int = 81,
        min_iter: int = 2,
        eta: int = 3,
        limit: float = 1.0,
    ):
        """
        Hyperband: A Novel Bandit-Based Approach to Hyperparameter.

        Optimization: https://arxiv.org/pdf/1603.06560.pdf

        Combining Hyperband and Bayesian Optimization: https://bayesopt.github.io/papers/2017/36.pdf

        Massively Parallel Hyperparameter Tuning:
        https://pdfs.semanticscholar.org/662d/788d5c75dc789186440656c7693912c4b1b6.pdf?_ga=2.232234015.1436859396.1539294657-1446250819.1539294657

        :param strategy: The wapped ``BayesSearch`` algorithm.
        :param budget_key: The hyperparameter name of the trial budget.
        :param max_iter: The budget translated to a number of iterations.
        :param min_iter:
        :param eta: The discount rate applied to the budget.
        :param limit: The proportion of jobs to finish before ranking and halving.
        """
        super().__init__()
        self._strategy = strategy
        self._max_iter = max_iter
        self._min_iter = min_iter
        self._eta = eta
        self._limit = limit
        self._budget_key = budget_key

        self._s_max = int(np.log(self._max_iter) / np.log(self._eta))

        self._results = []
        self._best_loss = np.inf
        self._suggested = 0
        self._init = False
        self._observed = 0
        self._iterator = None
        self._ready = True
        self._current_T = []
        self._nb_seen_round = 0
        logger.info("Start Hyperband", nb_rounds=self._s_max, limit=self._limit * 100)
        if self._limit < 1.0 / self._eta:
            raise ValueError(
                "You need to observe at least {}% of the trials".format(
                    (1.0 / self._eta) * 100
                )
            )
        # init strategy
        # because the max nb of trials asked by HB is max_iter
        # we need to set strategy.nb_trials to at least max_iter

        if self._strategy._nb_trials < self._max_iter:
            logger.info(
                "Patch strategy",
                nb_trials=self._strategy._nb_trials,
                patched_nb_trials=self._max_iter,
            )
            self._strategy._nb_trials = self._max_iter

    def observe(self, trials: List[Trial]) -> None:
        filtered_trials = [
            trial.copy(deep=True) for trial in trials if trial.result is not None
        ]
        nb_new_jobs = len(filtered_trials) - self._observed
        if nb_new_jobs > 0:
            self._observed = len(filtered_trials)
        else:
            return

        if not self._init:
            return

        for trial in filtered_trials:
            del trial.parameters[self._budget_key]

        seen_results = {}
        for id_trial, trial in enumerate(filtered_trials):
            _param = deepcopy(trial.parameters)
            _result = trial.result
            seen_results[id_trial] = (_param, _result)
        limit = int(np.ceil(self._limit * len(self._current_T)))

        self._nb_seen_round += nb_new_jobs
        logger.info("Observe", limit=limit, seen=self._nb_seen_round)
        if self._nb_seen_round >= limit:
            val_losses = [res[1] for id_trial, res in seen_results.items()]
            indices = np.argsort(np.array(val_losses).flatten())
            _keys = list(seen_results.keys())
            self._current_T = [seen_results[_keys[ind]][0] for ind in indices]
            if np.array(val_losses).flatten()[indices[0]] < self._best_loss:
                self._best_loss = val_losses[indices[0]]
                self.best_config = seen_results[_keys[indices[0]]][0]
            # cut should always be 0 if it's between 0 and 1
            cut = int(np.ceil(len(self._current_T) / self._eta))
            logger.info("Halving", current_len=len(self._current_T), new_len=cut)
            self._current_T = self._current_T[0:cut]
            self._nb_seen_round = 0
            self._ready = True

        self._strategy.observe(filtered_trials)

    def _step_opt(self):
        """Suggest a set of parameters. Randomly draw samples
        from the import space and return them.

        .. note:: New parameters must be compliant with the problem's domain
           `Space`.
        """
        parameters = self._strategy.suggest()
        return parameters

    def _get_new_iterator(self, n_iterations):
        for t in self._current_T:
            t[self._budget_key] = int(n_iterations)
            yield t

    def _get_nb_trials_round(self, s):
        return int(np.ceil((self._s_max + 1) / (s + 1) * self._eta ** s))

    def _step(self):
        for ite, s in enumerate(reversed(range(self._s_max + 1))):
            self._ready = True
            logger.info(
                "Begining round", current=self._s_max - s, max_round=self._s_max
            )
            # initial number of configurations
            self.n = self._get_nb_trials_round(s)
            logger.info("Set configs for subrounds", configs=self.n, subrounds=s)
            if ite == 0:
                self._strategy._optimizer._n_initial_points = self.n
                self._strategy._optimizer.n_initial_points_ = self.n

            # initial number of iterations per config
            self.r = self._max_iter * self._eta ** (-s)

            self._current_T = [self._step_opt() for _ in range(self.n)]
            self._init = True
            for i in range((s + 1)):  # changed from s + 1
                logger.info(
                    "Start subround",
                    subround=i,
                    tot_subrounds=s,
                    nb_configs=len(self._current_T),
                )
                n_iterations = np.ceil(self.r * self._eta ** (i))
                n_iterations = np.max([n_iterations, self._min_iter])
                while self._ready is False:
                    yield None
                self._ready = False
                iterator = self._get_new_iterator(n_iterations)
                for t in iterator:
                    self._strategy._suggested = 0
                    yield t

    def __len__(self):
        length_return = 0
        for ite, s in enumerate(reversed(range(self._s_max + 1))):
            n = self._get_nb_trials_round(s)
            for i in range((s + 1)):
                length_return += np.ceil(n * self._eta ** (-i))
        return int(length_return)

    def suggest(self):
        """Suggest a new set of parameters. Randomly draw samples
        from the import space and return them.

        .. note::
            New parameters must be compliant with the problem's domain `Space`.
        """
        if self._iterator is None:
            self._iterator = self._step()
        params = next(self._iterator)
        if params is not None:
            self._suggested += 1
        return params

    @classmethod
    def instantiate_from_config(cls, config: JsonSerializableDict) -> Algorithm:
        config = deepcopy(config)
        config["strategy"] = Algorithm.from_config(config["strategy"])
        if not isinstance(config["strategy"], BayesSearch):
            raise ValueError(
                f'Hyperband does not support the strategy "{type(config["strategy"])}". '
                f'Only "BayesSearch" is supported.'
            )
        return super().instantiate_from_config(config)

    def save(self):
        return {"suggested": self._suggested, "strategy_state": self._strategy.save()}

    def load(self, state):
        self._iterator = None
        self._suggested = state["suggested"]
        self._strategy.load(state["strategy_state"])
