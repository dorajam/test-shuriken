from typing import Dict, List, Union

import numpy as np

from eai.shuriken.algorithm.algorithm import Algorithm
from eai.shuriken.algorithm.dimensions import parse_dimension
from eai.shuriken.common.trial import Trial
from eai.shuriken.common.typing import JsonAtomic


class RandomSearch(Algorithm):
    def __init__(
        self,
        dimensions: Dict[str, Union[JsonAtomic, List[JsonAtomic]]],
        nb_trials=10,
        random_seed=1337,
    ):
        """
        Sample randomly from the problem's space.

        :param dimensions: The dimensions (hyperparameters) and their associated distribution.
            A distribution can be a unique value (with unit probability),
            a list of values (with uniform probability),
            or a random distribution defined by a string of the form ``"distribution(*args, **kwargs)"``.
            Any `scipy` distribution can be used, see the
            `scipy.stats documentation <https://docs.scipy.org/doc/scipy/reference/stats.html>__
            for a complete list of distributions and their available arguments.
            For example, a normal distribution centered at `4` and with a standard deviation of `3`
            can be defined by the string ``"norm(4, 3)"`` or ``"norm(loc = 4,  scale = 3)"``.
        :param nb_trials: The total number of samples to suggest.
        :param random_seed: The random seed for the random sampling.
            Does not affect the seed for the trials themselves.
        """
        super().__init__()
        self._dimensions = {
            name: parse_dimension(dimension) for name, dimension in dimensions.items()
        }

        self._nb_trials = nb_trials
        self._suggested = 0
        self._random_state = np.random.RandomState(random_seed)

    def suggest(self):
        if self._suggested >= self._nb_trials:
            raise StopIteration

        self._suggested += 1
        return {
            name: dimension.sample(self._random_state)
            for name, dimension in self._dimensions.items()
        }

    def observe(self, trials: List[Trial]) -> None:
        pass

    def __len__(self):
        return self._nb_trials

    def save(self):
        random_state = list(self._random_state.get_state())
        random_state[1] = random_state[1].tolist()
        return {"suggested": self._suggested, "random_state": random_state}

    def load(self, state):
        self._suggested = state["suggested"]
        self._random_state.set_state(state["random_state"])
