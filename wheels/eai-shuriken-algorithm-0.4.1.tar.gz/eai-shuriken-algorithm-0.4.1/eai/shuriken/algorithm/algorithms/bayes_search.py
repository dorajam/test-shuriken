import os
from typing import Any, Dict, List, Optional

import numpy as np
import structlog
from skopt import Optimizer

from eai.shuriken.algorithm.algorithm import Algorithm, separate_dimensions
from eai.shuriken.common.trial import Trial

logger = structlog.get_logger(__name__)


class BayesSearch(Algorithm):
    def __init__(
        self,
        dimensions,
        nb_trials: int = 10,
        base_estimator: str = "gp",
        n_initial_points: int = 10,
        acq_func: str = "gp_hedge",
        acq_optimizer: str = "auto",
        acq_func_kwargs: Optional[Dict[str, Any]] = None,
        acq_optimizer_kwargs: Optional[Dict[str, Any]] = None,
        random_seed: int = 1337,
    ):
        """
        A bayesian hyperparameter optimisation algorithm.
        This implementation wraps the ``Optimizer`` class from `scikit-optimize`.
        For more details, see `the documentation for that class
        <https://scikit-optimize.github.io/stable/modules/generated/skopt.optimizer.Optimizer.html#skopt.optimizer.Optimizer>`__.

        :param dimensions: The dimensions (hyperparameters) of the search space
            and their possible values or bounds (see skopt documentation).
        :param nb_trials: The total number of samples to suggest.
        :param base_estimator: See skopt documentation.
        :param n_initial_points:  See skopt documentation.
        :param acq_func: See skopt documentation.
        :param acq_optimizer: See skopt documentation.
        :param acq_func_kwargs: See skopt documentation.
        :param acq_optimizer_kwargs: See skopt documentation.
        :param random_seed: The random seed for the random sampler of the optimizer.
        """
        super().__init__()
        self._base_estimator = base_estimator
        self._random_state = np.random.RandomState(random_seed)
        self._dimensions, self.fixed_dimensions = separate_dimensions(dimensions)
        self._nb_trials = nb_trials
        self._suggested = 0
        _dimensions_values = [v for k, v in self._dimensions.items()]
        self._forbidden_keys = list(self.fixed_dimensions.keys())
        # TODO: remove this hack
        self._forbidden_keys += ["random_seed", "repeat", "config_index", "model_state"]
        self._optimizer = Optimizer(
            _dimensions_values,
            base_estimator=base_estimator,
            n_initial_points=n_initial_points,
            acq_func=acq_func,
            acq_optimizer=acq_optimizer,
            random_state=self._random_state,
            acq_func_kwargs=acq_func_kwargs,
            acq_optimizer_kwargs=acq_optimizer_kwargs,
        )
        self._base_estimator = base_estimator
        self._model_state = 0
        self._observed = 0
        self._max_points = int(os.environ.get("BAYESIAN_OPTIMIZER_MAX_POINTS", 400))
        if not isinstance(self._base_estimator, str):
            raise ValueError(
                "Your base estimator cannot be serialized and is not supported."
            )

    def suggest(self):
        """Suggest a new set of parameters. Randomly draw samples
        from the import space and return them.

        .. note:: New parameters must be compliant with the problem's domain
           `Space`.
        """
        if self._suggested >= self._nb_trials:
            raise StopIteration

        parameters = self._optimizer.ask()
        params = {}
        for k, v in zip(self._dimensions.keys(), parameters):
            if isinstance(v, np.number):
                v = v.item()
            params[k] = v
        for k, v in self.fixed_dimensions.items():
            params[k] = v
        params["model_state"] = self._model_state
        self._suggested += 1

        return params

    # def observe(self, params, results):
    def observe(self, trials: List[Trial]) -> None:
        filtered_trials = [trial for trial in trials if trial.result is not None]
        if len(filtered_trials) > self._observed:
            self._observed = len(filtered_trials)
        else:
            return

        if len(filtered_trials) > self._max_points:
            logger.info(
                "Subsample trial results",
                original_size=len(filtered_trials),
                nb_samples=self._max_points,
            )
            filtered_trials = self._random_state.choice(
                filtered_trials, self._max_points, replace=False
            )

        parameters = [
            [v for k, v in trial.parameters.items() if k not in self._forbidden_keys]
            for trial in filtered_trials
        ]

        results = [trial.result for trial in trials]

        # Clear Xi, yi of scikit optimize
        self._optimizer.Xi = []
        self._optimizer.yi = []

        # Observe
        self._model_state += 1
        self._optimizer.tell(parameters, results)

    def __len__(self):
        return self._nb_trials

    def save(self):
        return {
            "suggested": self._suggested,
            "random_state": self._random_state.get_state(),
        }

    def load(self, state):
        self._suggested = state["suggested"]
        self._random_state.set_state(state["random_state"])
