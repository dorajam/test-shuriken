from copy import deepcopy
from typing import List

from eai.shuriken.algorithm.algorithm import Algorithm
from eai.shuriken.common.trial import Trial
from eai.shuriken.common.typing import JsonSerializableDict


class RandomSeed(Algorithm):
    def __init__(self, random_seeds: List[int], strategy: Algorithm, repeat: int = 1):
        """
        Repeat a each suggested trial of an algorithm algorithm (strategy) with different seeds.
        Wrapping an algorithm with a custom ``observe`` method (such as ``BayesSearch`` and ``Hyperband``)
        is not recommended and may have unintended effects.

        :param random_seeds: The random seeds to use.
        :param strategy: The wrapped algorithm.
        :param repeat: The number of times to repeat the trial for each random seed.
        """
        super().__init__()
        self.random_seeds = random_seeds
        self.strategy = strategy
        self.repeat = repeat
        self.suggested = 0
        self._config_iterator = self._make_iterator()

    def _make_iterator(self):
        for j, config in enumerate(self.strategy):
            for i in range(self.repeat):
                for seed in self.random_seeds:
                    if config is not None:
                        config.update({"random_seed": seed})
                        config.update({"repeat": i})
                        config.update({"config_index": j})
                    self.suggested += 1
                    yield config

    def observe(self, trials: List[Trial]) -> None:
        self.strategy.observe(trials)

    @classmethod
    def instantiate_from_config(cls, config: JsonSerializableDict) -> Algorithm:
        config = deepcopy(config)
        strategy_config = config["strategy"]
        strategy = Algorithm.from_config(strategy_config)
        config["strategy"] = strategy
        return super().instantiate_from_config(config)

    def suggest(self):
        config_hp = next(self._config_iterator)
        return config_hp

    def __len__(self):
        return self.repeat * len(self.random_seeds) * len(self.strategy)

    def save(self):
        return {"suggested": self.suggested, "strategy_state": self.strategy.save()}

    def load(self, state):
        self.strategy.load(state["strategy_state"])
        self.suggested = state["suggested"]
