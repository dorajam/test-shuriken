import itertools
from typing import Dict, List, Union

from eai.shuriken.algorithm.algorithm import Algorithm
from eai.shuriken.common.trial import Trial
from eai.shuriken.common.typing import JsonAtomic


class GridSearch(Algorithm):
    def __init__(
        self, dimensions: Dict[str, Union[JsonAtomic, List[JsonAtomic]]] = None
    ):
        """
        A simple grid search.

        :param dimensions: The dimensions (hyperparameters) of the search space
            and the values to try for each of them,
            which can be either a fixed value or a list of values.
        """
        super().__init__()

        self._dimensions = (
            {}
            if dimensions is None
            else {
                key: (dimension if isinstance(dimension, list) else [dimension])
                for key, dimension in dimensions.items()
            }
        )
        self._length = 1
        for dimension in self._dimensions.values():
            self._length *= len(dimension)
        self._reset()

    def _reset(self):
        self._suggested = 0
        self._configurations = (
            dict(zip(self._dimensions.keys(), instance))
            for instance in itertools.product(*self._dimensions.values())
        )

    def __len__(self):
        return self._length

    def suggest(self):
        next_config = next(self._configurations)
        self._suggested += 1
        return next_config

    def observe(self, trials: List[Trial]) -> None:
        pass

    def save(self):
        return {"suggested": self._suggested}

    def load(self, state):
        self._reset()
        for _ in range(state["suggested"]):
            self.suggest()
