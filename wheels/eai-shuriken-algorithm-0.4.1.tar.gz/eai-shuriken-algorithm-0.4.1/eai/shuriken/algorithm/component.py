from __future__ import annotations

import abc
from dataclasses import asdict


class Component(abc.ABC):
    def get_config(self):
        config = asdict(self)
        parent_config = dict()
        parent_config["config"] = config
        parent_config["class_name"] = self.__class__.__name__
        return parent_config

    @abc.abstractmethod
    def get(self, class_name: str) -> Component:
        pass

    @classmethod
    def from_config(cls, config):
        class_name = config["class_name"]
        inner_config = config["config"]
        instance = cls.get(class_name)(**inner_config)
        return instance
