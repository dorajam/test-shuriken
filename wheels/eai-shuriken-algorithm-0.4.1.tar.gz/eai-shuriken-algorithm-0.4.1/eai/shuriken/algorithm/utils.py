import numpy as np


def translate_states(states):
    new_states = []
    for state in states:
        if isinstance(state, np.generic):
            new_states.append(state.item())
        elif isinstance(state, np.ndarray):
            new_states.append(state.tolist())
        elif isinstance(state, (int, float)):
            new_states.append(state)
        else:
            new_states.append(state)
    return new_states
