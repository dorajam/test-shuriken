from __future__ import annotations

import abc
from typing import Dict, List, Optional, Type

import numpy as np
import structlog

from eai.shuriken.common.trial import Trial
from eai.shuriken.common.typing import AlgorithmConfig, JsonSerializableDict

logger = structlog.get_logger(__name__)


class Algorithm(abc.ABC):
    """
    An abstract base class for algorithms.
    """

    @abc.abstractmethod
    def save(self) -> JsonSerializableDict:
        """
        Save the algorithm state to a Json-serializable dictionary.
        """
        pass

    @abc.abstractmethod
    def load(self, state: JsonSerializableDict) -> None:
        """
        Restore the algorithm from a saved state.
        """
        pass

    @abc.abstractmethod
    def observe(self, trials: List[Trial]) -> None:
        """
        Process a set of completed trials, if applicable.
        """
        pass

    @classmethod
    def from_config(cls, config: Optional[AlgorithmConfig]) -> Algorithm:
        """
        A factory method for instantiating an algorithm from its configuration.

        :param config: The algorithm configuration.
            If not provided or ``None``, return a ``TrivialSearch``.
        """
        if config is None:
            return TrivialSearch()
        class_name = config["name"]
        instance = _get(class_name).instantiate_from_config(config.get("config", {}))
        return instance

    @classmethod
    def instantiate_from_config(cls, config: JsonSerializableDict) -> Algorithm:
        return cls(**config)  # type: ignore

    def __iter__(self):
        return self

    def __next__(self):
        return self.suggest()

    @abc.abstractmethod
    def suggest(self):
        pass

    @abc.abstractmethod
    def __len__(self) -> int:
        pass


class TrivialSearch(Algorithm):
    def __init__(self, repeat=1):
        """
        Run a single trial with no hyperparameter, optionally repeating it multiple times.

        :param repeat: The number of times to repeat the trial.
        """
        super().__init__()
        self._suggested = 0
        self._repeat = repeat

    def __len__(self):
        return self._repeat

    def suggest(self):
        if self._suggested >= self._repeat:
            raise StopIteration()
        self._suggested += 1
        return {}

    def observe(self, trials: List[Trial]) -> None:
        pass

    def save(self):
        return {"suggested": self._suggested}

    def load(self, state):
        self._suggested = state["suggested"]


def _get(name: str) -> Type[Algorithm]:
    from eai.shuriken.algorithm.algorithms.bayes_search import BayesSearch
    from eai.shuriken.algorithm.algorithms.grid_search import GridSearch
    from eai.shuriken.algorithm.algorithms.hyperband import Hyperband
    from eai.shuriken.algorithm.algorithms.random_search import RandomSearch
    from eai.shuriken.algorithm.algorithms.random_seed import RandomSeed

    algorithms: Dict[str, Type[Algorithm]] = {
        "TrivialSearch": TrivialSearch,
        "RandomSeed": RandomSeed,
        "GridSearch": GridSearch,
        "RandomSearch": RandomSearch,
        "BayesSearch": BayesSearch,
        "Hyperband": Hyperband,
    }
    if name in algorithms:
        return algorithms[name]
    else:
        raise ValueError("{} not in the classes".format(name))


def separate_dimensions(dimensions, fixed=None, dist=None):
    if fixed is None:
        fixed = (bool, int, float, str, np.generic)
    if dist is None:
        dist = (list, tuple)
    dimensions_list = {}
    dimensions_fixed = {}
    for k, v in dimensions.items():
        if isinstance(v, dist):
            dimensions_list[k] = v
        elif v is None or isinstance(v, fixed):
            dimensions_fixed[k] = v
        else:
            message = f"{k}: {v}\n Should be either a list or in {fixed}"
            raise TypeError(message)
    return dimensions_list, dimensions_fixed
