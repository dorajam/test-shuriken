__package_name__ = "eai-shuriken-algorithm"
__version__ = "0.4.1"
