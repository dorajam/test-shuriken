from __future__ import annotations

import abc
from typing import Dict, List, Optional, Union

import numpy as np
import scipy.stats.distributions
import structlog

from eai.shuriken.common.exceptions import ShurikenValueError
from eai.shuriken.common.typing import StrictBool, StrictFloat, StrictInt
from eai.shuriken.common.utils import parse_function_string

logger = structlog.get_logger(__name__)

EPSILON = 1e-3

_DISTRIBUTIONS = [
    distribution
    for distribution in scipy.stats.distributions.__all__
    if isinstance(
        getattr(scipy.stats.distributions, distribution),
        (scipy.stats.rv_continuous, scipy.stats.rv_discrete),
    )
]


class Dimension(abc.ABC):
    @abc.abstractmethod
    def sample(self, random_state):
        pass


class FixedDimension(Dimension):
    def __init__(self, value: Union[StrictFloat, StrictInt, StrictBool, str, None]):
        self._value = value

    def sample(self, random_state):
        return self._value


class RandomDimension(Dimension):
    def __init__(
        self,
        prior: str,
        args: Optional[List[Union[float, int]]] = None,
        kwargs: Optional[Dict[str, Union[float, int]]] = None,
    ):
        if prior not in _DISTRIBUTIONS:
            raise ValueError(
                f"{prior} is not a supported distribution:\n"
                "https://docs.scipy.org/doc/scipy/reference/stats.html"
            )
        self._distribution = getattr(scipy.stats, prior)
        self._args = [] if args is None else args
        self._kwargs = {} if kwargs is None else kwargs
        try:
            # Make sure the arguments are valid.
            self.sample(np.random.RandomState())
        except Exception as e:
            raise TypeError(
                f"Invalid arguments for distribution {prior}: {str(e)}\n\n"
                f"See https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.{prior}.html"
            )

    def sample(self, random_state):
        value = self._distribution.rvs(
            random_state=random_state, *self._args, **self._kwargs
        )
        if isinstance(value, np.number):
            value = value.tolist()
        return value


class CategoricalDimension(Dimension):
    def __init__(
        self, values: List[Union[StrictFloat, StrictInt, StrictBool, str, None]]
    ):
        self._values = values

    def sample(self, random_state):
        value = random_state.choice(self._values)
        if isinstance(value, np.number):
            value = value.tolist()
        return value


def parse_dimension(dimension):
    # TODO: simplify parsing
    if isinstance(dimension, str):
        return _parse_scipy_dimension(dimension)
    elif isinstance(dimension, List):
        if len(dimension) == 0:
            raise ValueError("The dimension has no possible value.")
        elif len(dimension) == 1:
            return FixedDimension(value=dimension[0])
        else:
            return CategoricalDimension(values=dimension)
    else:
        return FixedDimension(value=dimension)


def _parse_scipy_dimension(dimension):
    try:
        prior, args, kwargs = parse_function_string(dimension)
    except ShurikenValueError:
        # Not a scipy distribution, assume the value is a constant string
        # TODO: better distinguish strings from scipy dimensions
        return FixedDimension(value=dimension)
    return RandomDimension(prior=prior, args=args, kwargs=kwargs)
