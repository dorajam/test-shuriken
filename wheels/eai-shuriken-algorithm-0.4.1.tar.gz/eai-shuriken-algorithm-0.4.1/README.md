# eai-shuriken-algorithm

## Usage

### Requirements

To run **eai-shuriken-algorithm**, you will need:

* Python ≥ 3.7


### Installing

To install **eai-shuriken-algorithm**, make sure you have access to the
[ElementAI internal PyPI eai-core
repo](https://pypi.elmt.io/dashboard/repositories/eai-core/), and that
`pip` is [configured to install packages from
there](https://github.com/ElementAI/pypi#using-pipconf). Then, run:

```
pip install eai-shuriken-algorithm
```
