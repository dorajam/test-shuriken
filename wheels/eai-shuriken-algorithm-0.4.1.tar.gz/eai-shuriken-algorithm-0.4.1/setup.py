# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['eai', 'eai.shuriken.algorithm', 'eai.shuriken.algorithm.algorithms']

package_data = \
{'': ['*']}

install_requires = \
['colorama>=0.4.1,<0.5.0',
 'eai-shuriken-common>=0.4.1,<0.5.0',
 'numpy>=1.19.2,<2.0.0',
 'pydantic>=1.5.1,<2.0.0',
 'scikit-optimize>=0.8.1,<0.9.0',
 'scipy>=1.5.2,<2.0.0',
 'structlog>=19.2.0,<20.0.0']

setup_kwargs = {
    'name': 'eai-shuriken-algorithm',
    'version': '0.4.1',
    'description': 'Shuriken',
    'long_description': '# eai-shuriken-algorithm\n\n## Usage\n\n### Requirements\n\nTo run **eai-shuriken-algorithm**, you will need:\n\n* Python ≥ 3.7\n\n\n### Installing\n\nTo install **eai-shuriken-algorithm**, make sure you have access to the\n[ElementAI internal PyPI eai-core\nrepo](https://pypi.elmt.io/dashboard/repositories/eai-core/), and that\n`pip` is [configured to install packages from\nthere](https://github.com/ElementAI/pypi#using-pipconf). Then, run:\n\n```\npip install eai-shuriken-algorithm\n```\n',
    'author': 'Element AI',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
