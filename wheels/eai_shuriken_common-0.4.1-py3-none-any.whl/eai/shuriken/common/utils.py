import re
import statistics
import time
from typing import Dict, List, Optional

from eai.shuriken.common.exceptions import ShurikenValueError
from eai.shuriken.common.typing import Environ


def string_to_bool(value: Optional[str], *, default: bool) -> bool:
    """
    Read a boolean from a string containing either the value "True" or "False".
    Case and external whitespace are ignored.

    :param value: The string to read.
    :param default: The value to return if ``value`` is ``None``.
    """
    if value is None:
        return default
    value = value.strip().lower()
    if value == "true":
        return True
    elif value == "false":
        return False
    raise ValueError(f'Invalid boolean string: "{value}"')


class Timer:
    def __init__(self):
        """
        A simple timer to measure non-overlapping intervals and
        calculate statistics about those intervals.
        """
        self._start_time: Optional[float] = None
        self._intervals: List[float] = []

    def start(self) -> None:
        """
        Start the timer.
        Raise an error if the timer is already running.
        """
        if self._start_time is not None:
            raise RuntimeError("Timer is already running")
        self._start_time = time.time()

    def stop(self) -> None:
        """
        Stop the timer and add the interval to the list of measured values.
        Raise an error if the timer is not running.
        """
        if self._start_time is None:
            raise RuntimeError("Timer is not running")
        self._intervals.append(time.time() - self._start_time)
        self._start_time = None

    def _format_time(self, value: float) -> float:
        """
        Convert a time interval to milliseconds an round the value.
        """
        return round(value * 1000, 2)

    def _get_stats(self) -> Dict[str, float]:
        """
        Return the last and average interval and the standard deviation in a dictionary.
        Values are in milliseconds.
        """
        return {
            "last": self._format_time(self._intervals[-1]),
            "avg": self._format_time(statistics.mean(self._intervals)),
            "std": self._format_time(statistics.pstdev(self._intervals)),
        }


def slugify(s: str) -> str:
    base = re.sub(r"[^a-z0-9]", " ", s.lower())
    return re.sub(r" +", "_", base.strip(" "))


def get_environment_from_list(environment_list: List[str]) -> Dict[str, str]:
    environment = {}
    for entry in environment_list:
        try:
            key, value = entry.split("=", 1)
        except ValueError:
            raise ValueError(
                f'The entry "{entry}" does not define a valid environment variable.'
            )
        if key in environment:
            raise ValueError(
                f'The environment variable "{key}" is defined multiple times.'
            )
        environment[key] = value
    return environment


def get_list_from_environment(environment: Environ) -> List[str]:
    return [f"{key}={value}" for key, value in environment.items()]


def parse_function_string(string):
    match = re.match(
        r"\s*(?P<function>\w+)\s*\((?P<args>(?P<arg>\w|\W|(,\s*)?)+)\)\s*", string
    )
    if match is None:
        raise ShurikenValueError(f"Not a function string: {string}")
    group_dict = match.groupdict()

    args = []
    kwargs = {}
    for arg in group_dict["args"].split(","):
        splitted_arg = [x.strip() for x in arg.split("=")]
        if len(splitted_arg) == 1:
            # Ignore empty entries
            if len(splitted_arg[0]) > 0:
                args.append(_parse_arg(splitted_arg[0]))
        elif len(splitted_arg) == 2:
            kwargs[splitted_arg[0]] = _parse_arg(splitted_arg[1])
        else:
            raise ValueError(f"{arg} is not a valid kwarg")
    return group_dict["function"], args, kwargs


def _parse_arg(arg):
    try:
        return int(arg)
    except ValueError:
        try:
            return float(arg)
        except ValueError:
            return arg
