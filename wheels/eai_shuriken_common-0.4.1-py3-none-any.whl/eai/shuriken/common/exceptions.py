class ShurikenError(Exception):
    """
    An exception raised by Shuriken.
    Unlike other exceptions, these should not leave the experiment
    in a corrupted state, and can be recovered from with proper handling.
    """

    pass


class ShurikenValueError(ShurikenError, ValueError):
    """
    A value error raised by Shuriken, usually due to invalid input.
    """

    pass


class ShurikenRuntimeError(ShurikenError, RuntimeError):
    """
    A runtime error raised by Shuriken, usually due to invalid runtime conditions.
    """

    pass
