from enum import Enum

# Use the class from `borgy_process_agent` if defined, otherwise redefine it here.

try:
    from borgy_process_agent.enums import State as JobState
except ImportError:

    class JobState(Enum):  # type: ignore
        # The NEW state is unique to the process
        # agent and does not exist on the ork
        # side.
        PENDING = "PENDING"
        SUBMITTED = "SUBMITTED"
        QUEUING = "QUEUING"
        QUEUED = "QUEUED"
        RUNNING = "RUNNING"
        CANCELLING = "CANCELLING"
        CANCELLED = "CANCELLED"
        SUCCEEDED = "SUCCEEDED"
        FAILED = "FAILED"
        INTERRUPTED = "INTERRUPTED"
        # This state is reserved for jobs
        # that were killed before ever being
        # acknowledged by the governor.
        KILLED = "KILLED"

        def is_finished(self):
            return self in [self.CANCELLED, self.FAILED, self.SUCCEEDED, self.KILLED]

        def is_alive(self):
            return self in [self.QUEUED, self.QUEUING, self.RUNNING, self.CANCELLING]

        def is_killable(self):
            return self in [self.RUNNING, self.QUEUING, self.QUEUED, self.PENDING]

        def is_rerunnable(self):
            return self in [self.CANCELLED, self.FAILED, self.INTERRUPTED]


# The terminated (Toolkit) job statuses, mapped o their mlflow equivalent.
TERMINATED_STATUSES = {
    JobState.SUCCEEDED: "FINISHED",
    JobState.FAILED: "FAILED",
    JobState.CANCELLED: "KILLED",
    JobState.KILLED: "KILLED",
}
