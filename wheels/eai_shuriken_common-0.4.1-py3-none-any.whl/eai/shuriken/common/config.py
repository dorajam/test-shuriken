from __future__ import annotations

from typing import Any, ClassVar, Dict, Optional, Type

import structlog
from pydantic import validator
from pydantic.main import BaseModel, Extra

logger = structlog.get_logger(__name__)


def get_module_attribute_name(object: Any) -> str:
    """
    Construct the fully qualified name of a class or function. For example,
    the fully qualified name for the `SomeClass` class from the `some.module` module
    is "some.module.SomeClass".

    :param object: An object living inside some module.
    """
    module_name = object.__module__
    attribute_name: str = object.__qualname__
    name = (
        attribute_name
        if module_name is None or module_name == "builtins"
        else f"{module_name}.{attribute_name}"
    )
    return name


class BaseConfig(BaseModel):
    """
    A base class for the pydantic configuration classes used in Shuriken.
    The configuration is set to prevent mutations and allow any object type.

    .note:
        While pydantic prevents mutations of the config class itself through ``setattr``,
        the attributes themselves can still be mutable.
    """

    __configurable_class__: ClassVar[Optional[Type[Configurable]]] = None  # = None
    # configurable_class: ClassVar[Type[Configurable]] = _ConfigurableReference()

    def instantiate(self, **kwargs: Any) -> Configurable:
        if self.__configurable_class__ is None:
            raise RuntimeError()
        return self.__configurable_class__(self, **kwargs)  # type: ignore

    class Config:
        allow_mutation = False
        arbitrary_types_allowed = True
        extra = Extra.forbid

    def __init_subclass__(cls):
        super().__init_subclass__()
        cls.__configurable_class__ = None


class Configurable:
    __configuration_classes__: ClassVar[Dict[str, Type[BaseConfig]]] = {}
    __configurable_classes__: ClassVar[Dict[Type[BaseConfig], Type[Configurable]]] = {}
    config_class: ClassVar[Type[BaseConfig]] = BaseConfig

    def __init_subclass__(cls):
        super().__init_subclass__()
        if not issubclass(cls.config_class, BaseConfig):
            raise ValueError(
                f'Invalid configuration class "{cls.config_class.__name__}".'
            )
        if (
            cls.config_class in cls.__configuration_classes__
            or cls.config_class.__configurable_class__ is not None
        ):
            raise ValueError(
                f'The configuration class "{cls.config_class.__name__}" is already in use.'
            )
        cls.__configuration_classes__[cls.__name__] = cls.config_class
        cls.__configuration_classes__[get_module_attribute_name(cls)] = cls.config_class
        cls.__configurable_classes__[cls.config_class] = cls
        cls.config_class.__configurable_class__ = cls

    @classmethod
    def get_config_class(cls, class_name: str) -> Type[BaseConfig]:
        if class_name not in cls.__configuration_classes__:
            raise ValueError()
        config_class = cls.__configuration_classes__[class_name]
        configurable_class = cls.__configurable_classes__[config_class]
        assert issubclass(configurable_class, cls)
        return config_class


# Manual `__init_subclass__` on `Configurable`
BaseConfig.__configurable_class__ = Configurable


def FactoryConfig(base_class: Type[Configurable]) -> Type[BaseConfig]:
    """
    A factory configuration class compatible with Pydantic.
    Instantiate a child configuration with a dynamically selected class.

    :param base_class: The configured object should belong to a subclass of this class.
    """

    class _FactoryConfig(BaseConfig):
        class_name: str
        config: Any

        @validator("config")
        def instantiate_config(cls, c, values):
            assert "class_name" in values
            assert values["class_name"] in base_class.__configuration_classes__
            config_cls = base_class.get_config_class(values["class_name"])
            return config_cls(**c)

    return _FactoryConfig
