import shutil
import traceback

import structlog

from eai.shuriken.common import __version__

ONLINE_DOCUMENTATION = "http://docs.libraries.elementai.net/eai-shuriken-runner/"
OLD_SHURIKEN_DOCUMENTATION = "http://docs.shuriken.elementai.lan/"
SLACK_CHANNEL = "#shuriken"

log = structlog.get_logger(__name__)


def get_terminal_width(minimum: int = 0, maximum: int = 120) -> int:
    """
    Evaluate the size of the terminal and constrain it to the provided bounds.

    :param minimum: A lower bound on the returned value.
    :param maximum: An upper bound on the returned value.
    """
    n_columns = shutil.get_terminal_size().columns
    return int(max(minimum, min(n_columns, maximum)))


def get_separator_line(mark: str = "=") -> str:
    """
    Return a separator line of the (constrained) terminal width made from the specified character.

    :param mark: The character to use for the line.
    """
    return mark * get_terminal_width()


class CliContext:
    """
    A context for handling welcome messages and uncaught exceptions while running a subcommand.
    """

    def __init__(self, package_name="eai-shuriken", version=__version__):
        self._package_name = package_name
        self._version = version

    def __enter__(self):
        log.info(
            f"Welcome to {self._package_name} {self._version}!\n{get_separator_line()}"
        )
        log.info(f"Shuriken documentation (work in progress): {ONLINE_DOCUMENTATION}")
        log.info(f"Old Shuriken documentation: {OLD_SHURIKEN_DOCUMENTATION}")
        log.info(f"Slack support channel: {SLACK_CHANNEL}")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            if exc_val is None or isinstance(exc_val, SystemExit):

                # Clean exit, nothing to do here.
                return
            elif isinstance(exc_val, KeyboardInterrupt):
                # Interruption case, suppress the error.
                raise SystemExit(1)
            else:
                # Failure case.
                log.error(traceback.format_exc())
                raise SystemExit(1)
        finally:
            log.info(f"Leaving {self._package_name}. Goodbye!\n{get_separator_line()}")
