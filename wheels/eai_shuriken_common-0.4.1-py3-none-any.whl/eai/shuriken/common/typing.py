"""
This module defines some types for clarification and validation purposes.
These "types" are meant for dynamic type validation with Pydantic
and would fail static type checks (with mypy),
so we replace the types by simpler ones for static checks.
The ``TYPE_CHECKING`` global constant is set to ``True`` during static checks.
"""
import re
from typing import TYPE_CHECKING, Any, Dict, List, Mapping, Union

from eai.shuriken.common.exceptions import ShurikenValueError

if TYPE_CHECKING:
    PositiveInt = int
    StrictStr = str
    StrictFloat = float
    StrictInt = int
    StrictBool = bool
else:
    # pylama: ignore=W0611
    from pydantic import PositiveInt, StrictStr, StrictFloat, StrictInt, StrictBool

if TYPE_CHECKING:
    MlflowString = str
else:
    _MLFLOW_STRING_PATTERN = re.compile(r"[\w.\- ]+")

    class MlflowString(str):
        """
        A string type that can be used to validate mlflow strings with pydantic.
        This type is more restrictive than mlflow and excludes the character "/"
        which can cause all sorts of problems related to paths.
        """

        @classmethod
        def __get_validators__(cls):
            yield cls.validate

        @staticmethod
        def validate(value):
            if not _MLFLOW_STRING_PATTERN.fullmatch(value):
                raise ShurikenValueError(
                    f'Invalid mlflow string "{value}". '
                    "Allowed characters are alphanumerics, underscores (_), dashes (-), periods (.),"
                    " and spaces ( )."
                )
            elif value in (".", ".."):
                raise ShurikenValueError(
                    f'Invalid mlflow string : value cannot be "{value}".'
                )
            return value


JsonAtomic = Union[StrictStr, StrictFloat, StrictBool, StrictInt, None]

if TYPE_CHECKING:
    # Mypy doesn't support recursive types
    JsonSerializable = Any
else:
    JsonSerializable = Union[
        JsonAtomic, List["JsonSerializable"], Dict[StrictStr, "JsonSerializable"]
    ]

JsonSerializableDict = Dict[StrictStr, JsonSerializable]

# TODO: Clarify what parameter values can be.
ParameterDict = JsonSerializableDict

# TODO: Clarify this type.
AlgorithmConfig = JsonSerializableDict

TrialId = StrictStr

Environ = Mapping[StrictStr, StrictStr]
