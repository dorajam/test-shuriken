# _logging.py
# Joel Lamy-Poirier, 2019-05-08
# Copyright (c) 2019 Element AI Inc. All rights reserved

import logging
import sys

import structlog


def configure_logging(
    level: int = logging.INFO, show_logger_name: bool = False
) -> None:
    """Configure logging with structlog.

    The eai default specification, as specified in the specification
    [0], with minor changes (configurable logging level and do not add
    the logger name by default).

    [0] https://github.com/ElementAI/eai-logging

    :param level: The logging level to use.
    :param show_logger_name: If enabled, show the logger name after each entry.
    """
    if structlog.is_configured():
        raise RuntimeError("Logging is already configured")

    pre_processors = [structlog.stdlib.filter_by_level]
    shared_processors = [
        structlog.stdlib.add_log_level,
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.UnicodeDecoder(),
    ]
    if show_logger_name:
        shared_processors.append(structlog.stdlib.add_logger_name)

    post_processors = [structlog.stdlib.ProcessorFormatter.wrap_for_formatter]

    structlog.configure_once(
        processors=pre_processors + shared_processors + post_processors,
        context_class=structlog.threadlocal.wrap_dict(dict),
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
        wrapper_class=structlog.stdlib.BoundLogger,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        processor=structlog.dev.ConsoleRenderer(), foreign_pre_chain=shared_processors
    )

    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setFormatter(formatter)
    root_logger = logging.getLogger()
    root_logger.addHandler(handler)
    root_logger.setLevel(level)
