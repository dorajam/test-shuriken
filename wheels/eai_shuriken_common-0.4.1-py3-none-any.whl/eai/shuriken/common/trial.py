from copy import deepcopy
from typing import Any, List, Optional

from pydantic import Field

from eai.shuriken.common.config import BaseConfig
from eai.shuriken.common.exceptions import ShurikenRuntimeError
from eai.shuriken.common.job_state import TERMINATED_STATUSES, JobState
from eai.shuriken.common.typing import ParameterDict, TrialId

try:
    from borgy_process_agent.job import Job
    from borgy_process_agent.models import OrkSpec
except ImportError:
    Job = Any
    OrkSpec = Any


class Trial(BaseConfig):
    """
    :param id: The trial id, i.e. the id of the associated mlflow run.
    :param parameters: The parameters for the trial.
    :param job_spec: The Toolkit job specification for the trial job.
    :param job_updates: The job updates received for the trial job, sorted chronologically.
       This attribute is mutable and can be updated through ``add_job_update``.
    """

    # TODO: Move to a separate file.
    id: TrialId
    parameters: ParameterDict
    job_spec: Optional[OrkSpec]
    job_updates: List[Job] = Field(default_factory=list)
    result: Optional[float] = None

    @property
    def state(self) -> JobState:
        return (
            JobState.PENDING
            if len(self.job_updates) == 0
            else self.job_updates[-1].state
        )

    def add_job_update(self, job_update: Job) -> None:
        """
        Add the provided job update to the list of received updates.

        :param job_update: The job update.
        """
        if self.state in TERMINATED_STATUSES:
            raise ShurikenRuntimeError(
                f'Cannot update a trial with final state "{self.state.name}"'
            )
        self.job_updates.append(deepcopy(job_update))

    def set_result(self, result: float) -> None:
        if self.result is not None:
            raise RuntimeError(f"Result already set for trial {self.id}")
        self.result = result
