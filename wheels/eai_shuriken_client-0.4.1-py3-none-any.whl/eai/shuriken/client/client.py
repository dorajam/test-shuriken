import json
import os
import time
from pathlib import Path
from typing import Dict, Optional

from pydantic import validate_arguments

from eai.shuriken.common.exceptions import ShurikenRuntimeError
from eai.shuriken.common.typing import Environ, JsonSerializable, MlflowString


class ShurikenClient:
    @validate_arguments
    def __init__(self, env: Optional[Environ] = None):
        """
        A simple client for interacting with Shuriken inside a worker.
        :param env: The environment to use for recovering the mlflow run, if different from ``os.environ``.
        """
        if env is None:
            env = os.environ
        try:
            mlflow_directory = Path(env["MLFLOW_TRACKING_URI"]).resolve()
            self._directory = (
                mlflow_directory / env["MLFLOW_EXPERIMENT_ID"] / env["MLFLOW_RUN_ID"]
            )
        except KeyError as e:
            raise ShurikenRuntimeError(f"Invalid environment: {str(e)}")
        if not self._directory.is_dir():
            raise ShurikenRuntimeError(f'No trial found at "{self._directory}".')

    def get_artifact_path(self) -> Path:
        """
        Get the artifact location for the Trial. This is where all user data generated during the trial should be saved.
        """
        return self._directory / "artifacts" / "user"

    def get_parameters(self) -> Dict[str, JsonSerializable]:
        """
        Get the parameters for the Trial.
        """
        parameters = {}
        parameter_dir = self._directory / "params"
        if parameter_dir.is_dir():
            for param_path in parameter_dir.iterdir():
                with param_path.open("r") as file_buffer:
                    parameters[param_path.name] = json.load(file_buffer)
        return parameters

    def get_tags(self) -> Dict[str, str]:
        """
        Get the tags for the Trial.
        """
        tags = {}
        tag_dir = self._directory / "tags"
        if tag_dir.is_dir():
            for tag_path in tag_dir.iterdir():
                with tag_path.open("r") as file_buffer:
                    tags[tag_path.name] = file_buffer.read()
        return tags

    @validate_arguments
    def post_metrics(
        self,
        metrics: Dict[MlflowString, float],
        step: Optional[int] = None,
        timestamp: Optional[int] = None,
    ) -> None:
        """
        Post a batch of metrics.
        # TODO: Is the step value still ignored in Viper?
        :param metrics: The metrics to post.
        :param step: The step (usually batch or epoch number) at which the metrics are posted.
        :param timestamp: A timestamp (in milliseconds) for the metric.
        """
        if timestamp is None:
            timestamp = int(time.time() * 1000)
        metric_dir = self._directory / "metrics"
        metric_dir.mkdir(exist_ok=True)
        for key, value in metrics.items():
            with (metric_dir / key).open("a") as file_buffer:
                if step is None:
                    file_buffer.write(f"{timestamp} {value}\n")
                else:
                    file_buffer.write(f"{timestamp} {value} {step}\n")
