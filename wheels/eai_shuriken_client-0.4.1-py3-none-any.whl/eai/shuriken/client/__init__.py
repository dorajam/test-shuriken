__package_name__ = "eai-shuriken-client"
__version__ = "0.4.1"
